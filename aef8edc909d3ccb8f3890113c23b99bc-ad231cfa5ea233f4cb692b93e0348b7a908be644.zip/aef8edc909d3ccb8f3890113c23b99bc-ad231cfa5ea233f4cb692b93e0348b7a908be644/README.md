## Requiremets
1. Node.js >= v18
2. Package markdown-table. 
Can be installed:
```bash
  npm i -g markdown-table 
``` 
3 .ENV variable AUTH_KEY to access google sheat api

## Usage
```bash 
 node index.js
```

After the script finish it generates markdown files for the specific language

P.S: If you have any questions, please write me in discord by @ruslan_mellifera