const fs = require('fs');
async function accessSpreadsheet() {
  const { markdownTable } = await import('markdown-table')
  const SPREADSHEET_ID = process.env.SPREADSHEET_ID ?? '1fARJjKnkUwEftRMdvCS0QxfQ2NAYKzD-xBLCqaIP4vw'
  const AUTH_KEY = process.env.AUTH_KEY
  const apiUrl = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/Лист1?key=${AUTH_KEY}`;
  const hyperLinkUrl = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}?ranges=Лист1!A2:A&fields=sheets(data(rowData(values(hyperlink,userEnteredValue))))&key=${AUTH_KEY}`;
  const sheetHyperlinks = await fetch(hyperLinkUrl).then(res => res.json())
  const originalHyperlinks = sheetHyperlinks.sheets[0].data[0].rowData.reduce((acc, cur) => {
    if (cur?.values[0]?.userEnteredValue?.stringValue) {
      acc[cur.values[0].userEnteredValue.stringValue.trim()] = cur.values[0].hyperlink ?? '';
      return acc;    
    }
    return acc;
  }, {})
  const sheet = await fetch(apiUrl).then(res => res.json())
  const LANGS = ['russian', 'ukrainian', 'indonesian', 'vietnamese', 'chinese ', 'turkish', 'italian', 'spanish', 'french', 'polish', 'german']


  // console.log(JSON.stringify(sheet, null, '\t') )
  const parsedDataByLangs = LANGS.reduce((acc, lang) => {
    const langIndex = sheet.values[0].findIndex(item => item.trim().toLowerCase() === lang.trim().toLowerCase())
    const authorIndex = sheet.values[0].findIndex((item, index) => index > langIndex && item.trim().toLowerCase() === 'author')
    acc[lang] = sheet.values.slice(1).map(item => {
      if (item[langIndex]) {
        return {
          language: lang,
          url: item[langIndex],
          originalUrl: item[0],
          author: item[authorIndex],
          date: item[1]
        }  
      }
    }).filter(Boolean)
    return acc; 
  }, {})
  const parsedDataOriginal = sheet.values.map(item => {
    if (originalHyperlinks[item[0]]) {
      return {
        thanksTo: 'NAMADA',
        language: 'english',
        url: originalHyperlinks[item[0]],
        originalName: item[0],
        date: item[1]
      }  
    }
  }).filter(Boolean)
  const optionLang = [
    // {
    //   key: 'language',
    //   label: 'Language'
    // },
    {
      key: 'author',
      label: 'Thanks to'
    },
    {
      key: 'originalUrl',
      label: 'Original Article'
    },
    {
      key: 'url',
      label: 'URL'
    }
  
    // {
    //   key: 'date',
    //   label: 'Date',
    // }
  ];
  const toTableDataLang = (array, option) => {
    const rows = array.map(item => {
      return option.map(({ key, label }) => {
        if (key === 'url') {
          return `<${item[key].trim()}>`
        }
        if (key === 'originalUrl') {
          const trimedName = item[key].trim()
          const hyperLink = originalHyperlinks[trimedName]
          const escapedName = `${trimedName}`.replace(' | ', ' \\| ')
          return hyperLink ? `[${escapedName}](${hyperLink})` : escapedName
        }

        return item[key].trim()
      })
    }).filter(Boolean)
    rows.unshift(option.map(item => item.label))
    return rows
  }
  const optionOrigin = [
    {
      key: 'thanksTo',
      label: 'Thanks to'
    },
    {
      key: 'originalName',
      label: 'Name'
    },
    {
      key: 'url',
      label: 'URL'
    },
    {
      key: 'date',
      label: 'Date',
    }
  ]
  const toTableDataOrigin = (array, option) => {
    const rows = array.map(item => {
      return option.map(({ key, label }) => {
        if (key === 'url') {
          return `<${item[key].trim()}>`
        }
        if (key === 'originalName') {
          const escapedName = `${item[key].trim()}`.replace(' | ', ' \\| ')
          return escapedName
        }

        return item[key].trim()
      })
    }).filter(Boolean)
    rows.unshift(option.map(item => item.label))
    return rows
  }
  // Generate language articles 
  for (const [language, parsedLanguageData] of Object.entries(parsedDataByLangs)) {
    const tableMarkdowm = markdownTable(toTableDataLang(parsedLanguageData, optionLang));
    fs.writeFileSync(`${language}.md`, tableMarkdowm, 'utf-8')
  }
  // Generate original English articles 
  const originalMarkdownTable = markdownTable(toTableDataOrigin(parsedDataOriginal, optionOrigin));
  fs.writeFileSync('english.md', originalMarkdownTable, 'utf-8')

}

accessSpreadsheet()
